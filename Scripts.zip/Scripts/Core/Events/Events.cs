﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Core.Events
{
    public class GameStartEvent { }

    public class GameFinishEvent { }

    public class PlayerSpawnEvent { }

    public class StorageEvent { }
}